// Thread placement and spin helpers shared by the CPU MoE pool and the locked-layer fetch threads.
#pragma once

#include <cstdlib>

#include "common.h"

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#define CPU_MOE_HAS_AFFINITY 1
#elif defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#define CPU_MOE_HAS_AFFINITY 1
#else
#define CPU_MOE_HAS_AFFINITY 0
#endif

namespace freetoken::cpu_moe {

inline void pin_this_thread(int cpu) {
#if CPU_MOE_HAS_AFFINITY && defined(_WIN32)
  // Single processor group (<= 64 logical CPUs).
  if (cpu >= 0 && cpu < 64) SetThreadAffinityMask(GetCurrentThread(), static_cast<DWORD_PTR>(1) << cpu);
#elif CPU_MOE_HAS_AFFINITY
  cpu_set_t set;
  CPU_ZERO(&set);
  CPU_SET(cpu, &set);
  pthread_setaffinity_np(pthread_self(), sizeof(set), &set);
#else
  (void)cpu;
#endif
}

inline void ecoqos_opt_out() {
#if defined(_WIN32)
  // Opt out of EcoQoS: Win11 otherwise throttles/parks pinned worker threads.
  const char* eco = getenv("FREETOKEN_MOE_ECOQOS_OPTOUT");
  if (!eco || *eco != '0') {
    THREAD_POWER_THROTTLING_STATE tp{THREAD_POWER_THROTTLING_CURRENT_VERSION,
                                     THREAD_POWER_THROTTLING_EXECUTION_SPEED, 0};
    SetThreadInformation(GetCurrentThread(), ThreadPowerThrottling, &tp, sizeof(tp));
  }
#endif
}

inline void cpu_relax() {
#if CPU_MOE_X86
  _mm_pause();
#elif defined(__aarch64__)
  asm volatile("yield" ::: "memory");
#endif
}

}  // namespace freetoken::cpu_moe
